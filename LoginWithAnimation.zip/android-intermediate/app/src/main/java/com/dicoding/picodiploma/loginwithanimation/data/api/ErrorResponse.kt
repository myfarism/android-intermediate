package com.dicoding.picodiploma.loginwithanimation.data.api

data class ErrorResponse(
    val error: Boolean,
    val message: String
)
